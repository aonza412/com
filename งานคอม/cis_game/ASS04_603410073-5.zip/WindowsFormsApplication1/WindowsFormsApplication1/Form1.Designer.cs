﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.start = new System.Windows.Forms.Button();
            this.b14 = new System.Windows.Forms.Button();
            this.b15 = new System.Windows.Forms.Button();
            this.end = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Stop = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b11 = new System.Windows.Forms.Button();
            this.b12 = new System.Windows.Forms.Button();
            this.b13 = new System.Windows.Forms.Button();
            this.b16 = new System.Windows.Forms.Button();
            this.b17 = new System.Windows.Forms.Button();
            this.b18 = new System.Windows.Forms.Button();
            this.b19 = new System.Windows.Forms.Button();
            this.ranbom = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // start
            // 
            this.start.BackColor = System.Drawing.Color.Gainsboro;
            this.start.Location = new System.Drawing.Point(160, 97);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(60, 54);
            this.start.TabIndex = 0;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = false;
            this.start.Click += new System.EventHandler(this.button1_Click);
            // 
            // b14
            // 
            this.b14.BackColor = System.Drawing.Color.Gainsboro;
            this.b14.Location = new System.Drawing.Point(556, 277);
            this.b14.Name = "b14";
            this.b14.Size = new System.Drawing.Size(60, 54);
            this.b14.TabIndex = 14;
            this.b14.Text = "14";
            this.b14.UseVisualStyleBackColor = false;
            // 
            // b15
            // 
            this.b15.BackColor = System.Drawing.Color.Gainsboro;
            this.b15.Location = new System.Drawing.Point(556, 217);
            this.b15.Name = "b15";
            this.b15.Size = new System.Drawing.Size(60, 54);
            this.b15.TabIndex = 15;
            this.b15.Text = "15";
            this.b15.UseVisualStyleBackColor = false;
            // 
            // end
            // 
            this.end.BackColor = System.Drawing.Color.Gainsboro;
            this.end.Location = new System.Drawing.Point(556, 97);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(60, 54);
            this.end.TabIndex = 20;
            this.end.Text = "The End";
            this.end.UseVisualStyleBackColor = false;
            this.end.Click += new System.EventHandler(this.button21_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Gainsboro;
            this.Close.Location = new System.Drawing.Point(631, 431);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(70, 33);
            this.Close.TabIndex = 22;
            this.Close.Text = "close";
            this.Close.UseVisualStyleBackColor = false;
            this.Close.Click += new System.EventHandler(this.button23_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(218, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(266, 55);
            this.label2.TabIndex = 24;
            this.label2.Text = "CIS GAME";
            // 
            // Stop
            // 
            this.Stop.BackColor = System.Drawing.Color.Gainsboro;
            this.Stop.Location = new System.Drawing.Point(160, 97);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(60, 54);
            this.Stop.TabIndex = 25;
            this.Stop.Text = "Reset";
            this.Stop.UseVisualStyleBackColor = false;
            this.Stop.Click += new System.EventHandler(this.start1_Click);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.Gainsboro;
            this.b1.Location = new System.Drawing.Point(94, 97);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(60, 54);
            this.b1.TabIndex = 1;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = false;
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Gainsboro;
            this.b2.Location = new System.Drawing.Point(94, 157);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(60, 54);
            this.b2.TabIndex = 2;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = false;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.Color.Gainsboro;
            this.b3.Location = new System.Drawing.Point(94, 217);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(60, 54);
            this.b3.TabIndex = 3;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = false;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.Color.Gainsboro;
            this.b4.Location = new System.Drawing.Point(94, 277);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(60, 54);
            this.b4.TabIndex = 4;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = false;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.Color.Gainsboro;
            this.b5.Location = new System.Drawing.Point(160, 277);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(60, 54);
            this.b5.TabIndex = 5;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = false;
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.Color.Gainsboro;
            this.b6.Location = new System.Drawing.Point(226, 277);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(60, 54);
            this.b6.TabIndex = 6;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = false;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.Color.Gainsboro;
            this.b7.Location = new System.Drawing.Point(292, 277);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(60, 54);
            this.b7.TabIndex = 7;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = false;
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.Color.Gainsboro;
            this.b8.Location = new System.Drawing.Point(292, 217);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(60, 54);
            this.b8.TabIndex = 8;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = false;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.Color.Gainsboro;
            this.b9.Location = new System.Drawing.Point(292, 157);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(60, 54);
            this.b9.TabIndex = 9;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = false;
            // 
            // b10
            // 
            this.b10.BackColor = System.Drawing.Color.Gainsboro;
            this.b10.Location = new System.Drawing.Point(292, 97);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(60, 54);
            this.b10.TabIndex = 10;
            this.b10.Text = "10";
            this.b10.UseVisualStyleBackColor = false;
            // 
            // b11
            // 
            this.b11.BackColor = System.Drawing.Color.Gainsboro;
            this.b11.Location = new System.Drawing.Point(358, 277);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(60, 54);
            this.b11.TabIndex = 11;
            this.b11.Text = "11";
            this.b11.UseVisualStyleBackColor = false;
            // 
            // b12
            // 
            this.b12.BackColor = System.Drawing.Color.Gainsboro;
            this.b12.Location = new System.Drawing.Point(424, 277);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(60, 54);
            this.b12.TabIndex = 12;
            this.b12.Text = "12";
            this.b12.UseVisualStyleBackColor = false;
            // 
            // b13
            // 
            this.b13.BackColor = System.Drawing.Color.Gainsboro;
            this.b13.Location = new System.Drawing.Point(490, 277);
            this.b13.Name = "b13";
            this.b13.Size = new System.Drawing.Size(60, 54);
            this.b13.TabIndex = 13;
            this.b13.Text = "13";
            this.b13.UseVisualStyleBackColor = false;
            // 
            // b16
            // 
            this.b16.BackColor = System.Drawing.Color.Gainsboro;
            this.b16.Location = new System.Drawing.Point(490, 187);
            this.b16.Name = "b16";
            this.b16.Size = new System.Drawing.Size(60, 54);
            this.b16.TabIndex = 16;
            this.b16.Text = "16";
            this.b16.UseVisualStyleBackColor = false;
            // 
            // b17
            // 
            this.b17.BackColor = System.Drawing.Color.Gainsboro;
            this.b17.Location = new System.Drawing.Point(424, 157);
            this.b17.Name = "b17";
            this.b17.Size = new System.Drawing.Size(60, 54);
            this.b17.TabIndex = 17;
            this.b17.Text = "17";
            this.b17.UseVisualStyleBackColor = false;
            // 
            // b18
            // 
            this.b18.BackColor = System.Drawing.Color.Gainsboro;
            this.b18.Location = new System.Drawing.Point(424, 97);
            this.b18.Name = "b18";
            this.b18.Size = new System.Drawing.Size(60, 54);
            this.b18.TabIndex = 18;
            this.b18.Text = "18";
            this.b18.UseVisualStyleBackColor = false;
            // 
            // b19
            // 
            this.b19.BackColor = System.Drawing.Color.Gainsboro;
            this.b19.Location = new System.Drawing.Point(490, 97);
            this.b19.Name = "b19";
            this.b19.Size = new System.Drawing.Size(60, 54);
            this.b19.TabIndex = 19;
            this.b19.Text = "19";
            this.b19.UseVisualStyleBackColor = false;
            // 
            // ranbom
            // 
            this.ranbom.BackColor = System.Drawing.Color.Gainsboro;
            this.ranbom.Location = new System.Drawing.Point(115, 379);
            this.ranbom.Name = "ranbom";
            this.ranbom.Size = new System.Drawing.Size(192, 54);
            this.ranbom.TabIndex = 21;
            this.ranbom.Text = "ทอยลูกเต๋า";
            this.ranbom.UseVisualStyleBackColor = false;
            this.ranbom.Click += new System.EventHandler(this.button22_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label.Location = new System.Drawing.Point(342, 382);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(142, 51);
            this.label.TabIndex = 23;
            this.label.Text = "          ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 476);
            this.Controls.Add(this.label);
            this.Controls.Add(this.ranbom);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.end);
            this.Controls.Add(this.b19);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.b18);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.b17);
            this.Controls.Add(this.start);
            this.Controls.Add(this.b16);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b15);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b14);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b13);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b12);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b11);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b10);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button b14;
        private System.Windows.Forms.Button b15;
        private System.Windows.Forms.Button end;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b10;
        private System.Windows.Forms.Button b11;
        private System.Windows.Forms.Button b12;
        private System.Windows.Forms.Button b13;
        private System.Windows.Forms.Button b16;
        private System.Windows.Forms.Button b17;
        private System.Windows.Forms.Button b18;
        private System.Windows.Forms.Button b19;
        private System.Windows.Forms.Button ranbom;
        private System.Windows.Forms.Label label;
    }
}

